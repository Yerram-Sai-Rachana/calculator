package calc;

public abstract class Variables {
	int numOne;
	int numTwo;
	
	Variables(int numOne,int numTwo){
		this.numOne = numOne;
		this.numTwo = numTwo;
	}

}
